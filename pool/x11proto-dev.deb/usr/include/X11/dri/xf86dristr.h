#warning "xf86dristr.h is obsolete and may be removed in the future."
#warning "include <X11/dri/xf86driproto.h> for the protocol defines."
#include <X11/dri/xf86driproto.h>
