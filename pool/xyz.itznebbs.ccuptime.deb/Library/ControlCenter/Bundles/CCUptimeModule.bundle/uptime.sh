#! /bin/bash
boot="$(sysctl -n kern.boottime)"
boot="${boot/\{ sec = }"
boot="${boot/,*}"

# Get current date in seconds.
now="$(date +%s)"
seconds="$((now - boot))"
days="$((seconds / 60 / 60 / 24)) days"
hours="$((seconds / 60 / 60 % 24)) hours"
mins="$((seconds / 60 % 60)) minutes"
((${days/ *} == 1))  && days="${days/s}"
((${hours/ *} == 1)) && hours="${hours/s}"
((${mins/ *} == 1))  && mins="${mins/s}"

# Hide empty fields.
((${days/ *} == 0))  && unset days
((${hours/ *} == 0)) && unset hours
((${mins/ *} == 0))  && unset mins

uptime="${days:+$days, }${hours:+$hours, }${mins}"
uptime="${uptime%', '}"
uptime="${uptime:-${seconds} seconds}"
echo $uptime