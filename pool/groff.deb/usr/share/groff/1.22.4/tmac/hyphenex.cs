% List of exceptions created by Karel Horak
% (Mathamatical Institute of Czechoslovak Acadamy of Science)
% Prague, April 1, 1991
%
\hyphenation{
  koe-fi-ci-ent
  koe-fi-ci-en-ty
  pro-jek-�n�
  �hlo-p���-ka
  �hlo-p���-ky
}

% ======================================================================
% Editor settings
% ======================================================================
%
% Local Variables:
% mode: tex
% coding: latin-2
% fill-column: 72
% End:
% vim: set filetype=tex textwidth=72:
