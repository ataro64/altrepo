/* Copyright © 0neguy Inc. 2019 */

var batInside = document.getElementById("batInside");
var batBox = document.getElementById("batBox");
var batIcon = document.getElementById("batIcon");
var battery = document.getElementById("battery");
var charging = document.getElementById("charging");
var batPercent = document.getElementById("percentage");
var device = document.getElementById("device");
var deviceIcon = document.getElementById("icon");
var widget = document.getElementById("widget");

/* 
var batteryPercent = 100;
var batteryCharging = 1;
var deviceName = "iPhone";
var front = 1;
var deviceType = "iphone";
var deviceModel = "xs";
var deviceColor = "black"
var lightMode = 0;
var widgetSize = "1.0";
var widgetOpacity = "1.0"
var widgetPadding = 20;
var showWhenCharge = 1;
var boxType = "normal"
*/

// Become blind basically in other words, light mode
// Don't you fucking dare to use this... I DARE YOU
function lightOn() {
    batBox.style.background = "rgba(255, 255, 255, 0.8)";
    batInside.style.filter = "invert(100%)";
    battery.style.filter = "invert(70%)";
    device.style.filter = "invert(70%)";
    charging.style.filter = "invert(70%)";
    /* document.body.style.background = "black"; */
    deviceIcon.style.filter = "none"
}

function setSize(type) {
    if (type === 0) {
        batBox.style.height = "65px";
        deviceIcon.style.top = "2px";
        deviceIcon.style.transform = "scale(0.8)";
        device.style.lineHeight = "65px";
        battery.style.lineHeight = "65px";
        batIcon.style.marginTop = "8px";
        charging.style.marginTop = "23px";
        batBox.style.marginTop = "-32px";
    } else if (type === 1) {
        batBox.style.height = "90px";
        deviceIcon.style.top = "13px";
        device.style.lineHeight = "90px";
        battery.style.lineHeight = "90px";
        batIcon.style.marginTop = "20px";
        charging.style.marginTop = "35px";
        batBox.style.marginTop = "-45px";
    } else if (type === 2) {
        batBox.style.height = "120px";
        deviceIcon.style.top = "28px";
        device.style.lineHeight = "120px";
        battery.style.lineHeight = "120px";
        batIcon.style.marginTop = "35px";
        charging.style.marginTop = "50px";
        batBox.style.marginTop = "-60px";
    }
}

function prefs() {
    boxType = boxType.toLowerCase();

    if (boxType === "thin") {
        setSize(0);
    } else if (boxType === "big") { // I like em big, i like em chunky... This is a dead meme sorry
        setSize(1);
    } else if (boxType === "xl") {
        setSize(2);
    }

    batBox.style.right = widgetPadding + "px";
    batBox.style.left = widgetPadding + "px";
    widget.style.opacity = widgetOpacity;
    if (lightMode === 1) {
        lightOn();
    }

    deviceColor = deviceColor.toLowerCase();
    deviceType = deviceType.toLowerCase();
    deviceModel = deviceModel.toLowerCase();

    device.innerHTML = deviceName;
    if (deviceColor === "silver" || deviceColor === "white" || deviceColor === "rose_gold" || deviceColor === "gold") {
        deviceIcon.style.filter = "none";
    }
    if (front === 1) {
        deviceIcon.style.backgroundImage = "url(img/" + deviceType + "/" + deviceModel + "/front/" + deviceColor + ".png)"
    } else if (front === 0) {
        deviceIcon.style.backgroundImage = "url(img/" + deviceType + "/" + deviceModel + "/back/" + deviceColor + ".png)"
    }
}

prefs();

function update() {
    batPercent.innerHTML = batteryPercent;

    // Why does switch not support logical operators... D;
    if (batteryPercent >= 95) {
        batInside.style.width = "32px";
    } else if (batteryPercent >= 90) {
        batInside.style.width = "28px";
    } else if (batteryPercent >= 80) {
        batInside.style.width = "24px";
    } else if (batteryPercent >= 70) {
        batInside.style.width = "22px";
    } else if (batteryPercent >= 60) {
        batInside.style.width = "20px";
    } else if (batteryPercent >= 50) {
        batInside.style.width = "16px";
    } else if (batteryPercent >= 40) {
        batInside.style.width = "13px";
    } else if (batteryPercent >= 30) {
        batInside.style.width = "8px";
    } else if (batteryPercent >= 20) {
        batInside.style.width = "5px";
    } else if (batteryPercent <= 10) {
        batInside.style.width = "3px";
    }
}

setTimeout(() => {
    update()
}, 100)


function isCharging() {
    if (batteryPercent > 20) {
        batInside.style.background = "#76F976";
    } else {
        batInside.style.background = "#FE0000";
    }

    battery.style.right = "30px";
    charging.style.transform = "scale(1.0)"

    if (showWhenCharge === 1) {
        show();
    }
}

function notCharging() {
    if (batteryPercent <= 20) {
        batInside.style.background = "#FE0000";
    } else {
        batInside.style.background = "#FFF";
    }
    
    battery.style.right = "10px";
    charging.style.transform = "scale(0.0)"

    if (showWhenCharge === 1) {
        hide();
    }
}

function show() {
    batBox.style.transform = "scale(" + widgetSize + ")";    
    batBox.style.opacity = "1.0"
}

var newSize = widgetSize - 0.2;
batBox.style.transition = "all 0.35s ease-in-out";
batBox.style.transform = "scale(" + newSize + ")"

function hide() {
    batBox.style.transform = "scale(" + newSize + ")";    
    batBox.style.opacity = "0.0"
}

setTimeout(() => {
    if (showWhenCharge === 0) {
        show();
    }
}, 300)
setInterval(() => {
    if (batteryCharging === 1) {
        isCharging();
    } else {
        notCharging();
    }
}, 500)

setInterval(() => {
    update()
}, 10000)

/* setInterval(() => {
    if (batteryPercent > 0) {
        batteryPercent--
    } else {
        batteryPercent = 100
    }
}, 1000) */